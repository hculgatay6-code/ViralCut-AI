# ViralCut AI v18.1 Beta

## Windows EXE

- `release\ViralCut-AI-v18.1-beta-Setup.exe` Windows x64 için kullanıcı başına kurulur. Masaüstü ve Başlat menüsüne kısayol ekler. Windows **Ayarlar → Uygulamalar** üzerinden kaldırılabilir.
- `release\ViralCut-AI-v18.1-beta-Portable.exe` kurulumsuz açılır. Geçici klasöre çıkarma sırasında ilk pencere gecikebilir.
- Kurulum dosyasının doğrulaması için `release\SHA256SUMS-v18.1-beta.txt` dosyasını kullan.

Uygulama **ViralCut AI v18.1 Beta** adıyla açılır. Eski `.viralcut` dosyalarını **Proje aç** ile yükle. Beta kendi ayar ve tanılama klasörünü kullanır. Beta kaydı bulunmadığında mevcut v18 kurtarma kaydı okunabilir. v18 takvimi beta takvimine ilk kayda kadar kaynak olabilir. YouTube bağlantısı beta’da tekrar yetkilendirilebilir.

Windows 10/11 x64 hedeflenir. Kurulum için ayrıca Node.js veya tarayıcı gerekmez. Kurulum dosyası imzasızdır. Yerel düzenleme ve MP4 dışa aktarma çevrimdışı çalışır. Whisper çalıştırması Windows x64 Visual C++ çalışma zamanını gerektirebilir. Whisper Base Q5, semantik ve görsel AI modelleri seçilecek veya ayrı indirilecek dosyalardır. [Üçüncü taraf bildirimleri](THIRD_PARTY_NOTICES.md)

## Kurtarma, ayarlar ve geri bildirim

**Ayarlar → Otomatik kayıt aralığı** seçeneği varsayılan 5 saniyedir. 15, 30 veya 60 saniyeye alabilir ya da kapatabilirsin. Proje üzerinde değişiklik olduğunda kontrol noktası oluşturulur. **Otomatik kaydı kurtar** ile açılışta geri dön. Önceki kayıt, son dosya okunamadığında denenir. Kaynak videolar bağlantı olarak saklanır. Eksik videoları medya listesinden yeniden bağla.

**Yerel tanılama → Raporu dışa aktar** işlem kodlarını ve sürelerini JSON olarak kaydeder. Raporda video dosyası, proje yolu, transkript, erişim anahtarı veya bellek dökümü bulunmaz. Dosyayı paylaşmadan önce inceleyebilirsin.

**Ayarlar** içinde GitHub deposunu `sahip/depo` olarak kaydet. **Güncellemeleri kontrol et** yeni erişilebilir sürümü ve sürüm notlarını gösterir. Uygulama güncellemeyi indirmez veya kurmaz. Özel depolar için **Sürüm sayfasını aç** bağlantısını oturum açık GitHub’da kullan. **GitHub Issues ile geri bildirim** bağlantısı yalnızca tarayıcı sayfasını açar.

## Kapalı beta sürüm hazırlığı

GitHub paketleme iş akışı depodaki `windows-media-v18` etiketi altında SHA-256 ile doğrulanan `ViralCut-Windows-Media-v18.zip` varlığını arar. Yerel geliştirmede mevcut `desktop-resources` klasörünü kullan. Temiz bir klasöre yerel arşivden araçları almak için `./scripts/restore-windows-media.ps1 -Archive <arşiv-yolu>` çalıştır. Paketleme için Node.js 24 x64, `npm ci`, `npm run lint`, `npm test`, `npm run package:win -- --publish never` ve `./scripts/write-beta-checksums.ps1` kullan. GitHub Actions, elle başlatıldığında EXE’leri ve kontrol toplamı dosyasını bir çalışma çıktısı olarak saklar.

[Değişiklik günlüğü](CHANGELOG.md) · [Kapalı beta yayın taslağı](RELEASE-v18.1-beta.md) · [Uygulama lisansı](LICENSE)

## Yayın Stüdyosu

**Yayın → Kaynak video seç → Videoyu analiz et ve klip seç** yolunu izle. Klip sayısını ve hedef süreyi seç, beş başlık önerisini incele, metni düzenle ve hedef platformları işaretle. Başlık, açıklama ve etiket önerileri yerel transkript, görsel model etiketleri ve şablonlara dayanır. Seçilen dil arayüz metinlerini ve şablonları değiştirir. Transkript alıntıları özgün dilinde kalır.

**MP4 ve metadata paketlerini hazırla** seçilen hedefler için ayrı 1080 × 1920 MP4, JSON ve JPEG oluşturur. Profiller 9:16 H.264/AAC kullanır. **Dışa aktarma profillerini düzenle** bölümünden FPS, hedef video bit hızı ve süre sınırını ayarlayabilirsin. Bit hızı kodlayıcı hedefidir. Dosya boyutu, çözünürlük, codec, FPS ve süre dışa aktarımdan sonra denetlenir. **Kapak düzenle** altında altı stil, düzenlenebilir başlık ve PNG/JPG kaydı bulunur. Özelleştirdiğin kapak, seçtiğin dosyaya kaydedilir. Paket JPEG’i video karesinden otomatik üretilir.

**Yerel içerik takvimi** taslakları, hazırlanan dosya adlarını ve seçtiğin tarihleri saklar. Takvim tarihleri planlama içindir. Uygulama kapalıyken görev başlatılmaz. TikTok ve Instagram için **Paket klasörünü aç** seçeneğinden ulaştığın MP4 ve metadata ile kendi hesabına manuel yükleyebilirsin.

YouTube için **Hesaplar ve yayınlama** bölümünden kendi Google Cloud projenin **Masaüstü uygulaması** türündeki OAuth JSON dosyasını seç. YouTube Data API v3 etkin ve hesabın OAuth izinleri verilmiş olmalı. OAuth yetkilendirmesi harici tarayıcıda açılır. Windows, bağlantı bilgilerini şifreli olarak saklar. Uygulama hedef kanal, görünürlük ve metni gösterir. Video gönderimi ayrı onay ister. Google’ın kabul ettiği zamanlanmış gönderim, gelecekteki bir tarih ile **Özel** görünürlüğü kullanır. Canlı yükleme ve hesapla zamanlama yetkili bir test hesabıyla doğrulanmayı bekliyor.

Testler ve platform kapsamı [v18 doğrulama raporunda](V18_TEST_RAPORU.md) bulunur.

## AI Copilot

Araç çubuğundan **AI Copilot**’u aç. Kaynak seçili değilse **Video seç** yazabilirsin. **Plan oluştur** komutu ayrıştırır. Planı okuyup **Planı uygula** düğmesine bas. Reddettiğin plan uygulanmaz. MP4 ve proje hedefleri için Windows dosya veya klasör seçicisi açılır.

- **İlk 10 saniyeyi kaldır ve videoyu 9:16 formatına dönüştür ve 720p MP4 kaydet.**
- **En iyi 5 Shorts’u oluştur.** Ardından **İkinciyi çıkar.** veya **Altyazıları sarı yap.**
- **İkinci klibi 5 saniye kısalt, altyazısını büyüt ve daha parlak yap.** Klip kısaltma ve parlaklık ikinci klibe uygulanır. Altyazı boyutu mevcut proje görünümünde ortaktır.
- **Remove from 00:10 to 00:20, then add subtitles.**

Yorumlayıcı Türkçe ve İngilizce için yerel kurallar kullanır. Kalite, mizah ve duyguyu genelleyen bir dil modeli yoktur. Klip seçimi mevcut görsel ve konuşma analizine dayanır. Belirsizlikte komutu süre ve klip numarasıyla yeniden yaz. Proje değiştiğinde veya kaynak değiştirdiğinde plan yenilenir. Düzenlemeler proje geçmişine kaydolur. Shorts aday listesi kendi geri alma geçmişine sahiptir. Dışa aktarılan dosyalar geri alma sırasında silinmez.

**Mikrofonla konuş** ile kayıt başlar. **Kaydı bitir** ile durdurabilirsin. Kayıt en fazla 15 saniyedir. Windows mikrofon izni ve mevcut yerel Whisper modeli gerekir. Arayüz dili konuşma tanıma dilini belirler. Kaydın metni önce sohbet ve düzenleme planında gösterilir. Metin komutları mikrofon olmadan çalışır.

## Performans Merkezi

**Performans** sekmesinde Electron işlemcisini, ana süreç ve arayüz belleğini, sistem RAM’ini, boş geçici disk alanını, ölçülebiliyorsa NVIDIA GPU/VRAM’i ve son işlem sürelerini görebilirsin. Ağır işler tek sırada çalışır, bellek azaldığında yeni ağır iş bekler. Bekleyen işi başlattığın araçtan iptal edebilirsin.

- **Eco** işlemci iş parçacıklarını sınırlar ve kullanılmayan analiz kaynaklarını boşaltır.
- **Balanced** varsayılandır. Uygun job’larda NVENC kodlaması devam eder.
- **Performance** destek gerçek FFmpeg denemesiyle doğrulanırsa, uygun H.264/HEVC kaynaklarda donanımla çözmeyi dener. Arıza durumunda işlem CPU çözmeye döner. Altyazı ve görüntü filtreleri mevcut CPU yolunda işlenir.

Tamamlanan, doğrulanmış yerel klip analizleri aynı kaynak ve analiz ayarlarıyla tekrar kullanılabilir. Sonuçlar transkript ve zaman bilgisi içerebilir. Önbellek bu uygulama profilinde en fazla 48 MiB / 24 kayıt tutar. Gerektiğinde **Analiz önbelleğini temizle** seçeneğini kullan. Analiz ortasında kapanırsa işlem yeniden başlar. Tamamlanmış ve önbelleğe yazılmış analizler yeniden açıldığında kullanılabilir. Kaynak videolar bu klasöre kopyalanmaz.

## AI Otonom Editör

1. Sol araç çubuğunda **Yönetmen** sekmesini aç ve **Yönetmen için video seç** düğmesiyle kaynak videoyu seç.
2. **Tam otomatik** veya **Manuel onay** modunu, hedef klip süresini, çıktı sayısını ve çözünürlüğü seç. Süreler hedef değerdir. Cümle sınırları ve sessizlik temizleme nedeniyle sonuç değişebilir.
3. **AI ile Otomatik Düzenle** düğmesine bas. Tam otomatik modda çıktı klasörünü başta seç. Manuel onay modunda klipleri önizle, başlangıç ve bitişi düzenle, istemediğin klipleri kaldır ve **Planı MP4 ve proje olarak kaydet** düğmesini kullan.
4. Uygulama seçilen klasörde her işlem için ayrı bir alt klasör açar. `Short-*.viralcut` dosyaları düzenlenebilir kurguları, `Edit-plan.json` kaynak zamanlarını ve kesme kararlarını içerir. Doğrulanan MP4 dosyalarını aynı klasörde bulabilirsin. Kaynak video yerinde kalır. Projeyi başka bir bilgisayara taşırken kaynağı ayrıca taşı ve gerektiğinde projeden yeniden bağla.
5. Bir klipte sorun oluşursa rapora bak. Oluşturulan projeler ve tamamlanan MP4 dosyaları korunur. Bunları açıp düzenleyerek yeniden dışa aktarabilirsin. Analiz otomatik olarak kaldığı aşamadan devam etmez.

Yönetmen, konuşma ve görsel analizden gelen kanıtları kullanır. Örtüşen ve benzer adayları eler. Başlıkta gösterilen puan kurgu uygunluğunu ifade eder. Yeterince farklı aday bulunamazsa seçilen sayıdan az klip üretilebilir. Kaynak sessizse konuşma altyazısı atlanır. Modeller ve video dosyaları yerelde işlenir. Ölçüm ayrıntıları ve doğrulama kapsamı [v17 test raporunda](V17_TEST_RAPORU.md) yer alır.

**Kamera, altyazı, renk ve ses** altında otomatik takip, sabit merkez ya da tam kare seçebilirsin. Oyun profilinin otomatik kamerası oyun arayüzünü korumak için tüm kareyi dikey tuvale sığdırır. Otomatik renk, örneklenen parlaklık ve renk dağılımından sınırlı düzeltmeler üretir. Altı altyazı stili arasından seçim yapabilirsin. Kelime vurgusu için güvenilir sözcük zamanları kullanılır.

Ses panelinde −24 ile −14 LUFS arasında hedef seçebilir ve hafif gürültü azaltmayı açabilirsin. Yalnızca kullanma hakkın olan yerel MP3, WAV, M4A veya FLAC dosyalarını seç. İşlenen ses yüksekliği ve true peak, dışa aktarılan dosyadan ölçülür. Önce **Orijinal görüntü ve ses**, çıktı alındıktan sonra **İşlenmiş görüntü ve ses** düğmesiyle kaynak ile son MP4’ü karşılaştırabilirsin. Yerel müzik, Stüdyo dışa aktarmasında karışır. Düzenlenebilir proje dosyasına müzik bağlantısı eklenmez.

## Visual AI

**AI Araçları → Tek Tıkla Shorts** altında Genel veya Oyun / aksiyon analizi seç. Genel analiz mevcutsa konuşma, ses ve görsel ölçümleri birleştirir. Oyun modu hareket ve sahne/ekran değişimlerine daha fazla ağırlık verir. Sessiz video doğrudan görsel analize alınır ve ses akışı eklenmeden dışa aktarılır. **Visual AI sahneleri** altında zaman damgasına tıklayarak olayın çevresini izle. Model etiketleri olasılıklı tahminlerdir; oyun skoru, zafer veya öldürme olayı tanımlanmaz.

**Ayarlar → Otomatik konu kadrajı** genel moddaki model tespitlerini kullanır. Konu kaybolduğunda kadraj merkeze yaklaşır. Zoom veya konum kaydırıcısını elle değiştirmek otomatik kadrajı kapatır. Çok kişili görüntüde kadraj farklı bir kişiye kayabilir. Hızlı hareket ve kısa sahneler örnekler arasında kalabilir.

SSD MobileNet INT8 (9,54 MB, Apache-2.0) ve Ultra-Light Slim (1,20 MB, MIT) dosyaları `%LOCALAPPDATA%\ViralCutAI\vision-v13` konumundan doğrulanarak yüklenir. Başka bir bilgisayarda `scripts\setup-vision.ps1` ile onay vererek kurabilirsin. Kurulduktan sonra ağ bağlantısı gerekmez. Modeller eksikse hareket ve sahne ölçümleri kullanılabilir. Nesne motoru CPU kullanır. Yüz motoru otomatik seçimde DirectML’i dener, başlatılamazsa CPU kullanır. [SSD MobileNet INT8](https://huggingface.co/onnxmodelzoo/ssd_mobilenet_v1_12-int8) · [Ultra-Light Slim](https://github.com/Linzaer/Ultra-Light-Fast-Generic-Face-Detector-1MB)

**Tek Tıkla Shorts** analizinde sessizlik, konuşma, ses enerjisi ve sahne geçişleri ile klip sıralaması ayrı aşamalar olarak gösterilir. Bir adayın puanını açarak kullanılan ölçütleri görebilirsin. Kaydedilen kliplerde uzun siyah aralıklar veya çok düşük ses ayrıca uyarıyla gösterilir. Çözülemeyen veya süre, ses, çözünürlük ve kare hızı kontrolünü geçemeyen klipler kaydedilmez.

Sağ paneldeki **Yerel tanılama** bölümü son 120 işlem kaydını gösterir. Süre, işlem türü, sonuç ve gerekirse sınırlı bir hata kodu kaydedilir. Dosya yolları, video, transkript veya ham araç çıktısı kayda girmez. Kayıt uygulama profilinde saklanır. Proxy ve dalga formu hazırlığı dışa aktarma veya analiz başlayınca sıraya döner ve ağır işlem bitince yeniden başlar. Kod denetimi için `npm run lint` kullanılabilir.

## Altyazı şablonları ve kapaklar

1. **Altyazı → Şablonlar ve animasyonlar** bölümünden on şablondan birini seç. Video önizlemesinde konuşma zamanına git veya altyazı örneğini göster. Animasyon, hız, yazı tipi, renk, boyut ve konumu ayarla. Beğendiğin ayarları **Şablonu kaydet** ile yerel kütüphanene ekle. Aynı adla kaydetmek o şablonun ayarlarını günceller.
2. Sağ panelde **Altyazı güvenli alanı** seçeneğini aç. Kılavuz önizlemede kalır. Uzun altyazılar satırlara bölünür. Taşma uyarısı varsa boyutu küçült, metni böl veya dikey konumu değiştir. Bu kılavuz genel bir 9:16 önizleme yardımıdır.
3. Kelime vurgusu ve birikimli karaoke Whisper kelime zamanlarını kullanır. Dönüşümlü renk zamanlı kelimeler arasında değişir. Belirgin kelime kuralı sayı içeren veya en az yedi harfli aktif kelimeleri vurgular. Zamanları eksik ya da yapısal olarak tutarsız altyazılarda seçili kelime efekti cümle düzeyinde fade ile değiştirilir. SRT/VTT düz metin ve zaman bilgisiyle kaydedilir. Animasyon ve renk MP4 çıktısına işlenir.
4. **Kapak** sekmesinde üç kare önerisini ya da zaman kaydırıcısını kullan. Konuşmadan kısa bir alıntı seçebilir ve başlığı düzenleyebilirsin. Dikey 1080 × 1920 veya yatay 1920 × 1080 seçip PNG/JPG kaydet. Kapak ayrı bir resim dosyasıdır.
5. **Tek Tıkla Shorts** analizinden sonra aynı şablon kontrollerini kullan. Seçtiğin klibi **Önizleme** ile oynat ve **Kapak hazırla** ile klibin zaman aralığından kapak seç. Toplu MP4 dışa aktarma o anda seçili altyazı ayarlarını kullanır.

FFmpeg yazı çizimi ile canlı önizleme ortak zamanlama ve hareket kurallarını kullanır. Sistem yazı tipi metrikleri, sıkıştırma ve video kare hızı satır sonlarında ve animasyon çiziminde küçük farklar yaratabilir.

## Efektler, geçişler ve ses

- **Efektler → Görüntü ve hareket** altında iki anahtar kareli yakınlaşma veya uzaklaşma, üç düzenlenebilir renk ön ayarı, parlaklık, kontrast, doygunluk ve keskinlik bulunur. Konuşma zamanlarından zoom önerisi **Öneriyi uygula** ile etkinleşir. Canlı renk gösterimi yaklaşık, **İşlenmiş örnek** FFmpeg ile gerçek çıktı filtrelerini kullanır.
- **Ses → Ses stüdyosu** altında gürültü azaltma, konuşma EQ'su, dinamik ses seviyesi dengeleme ve başlangıç/bitiş fade ayarları vardır. **Orijinal örnek** ve **İşlenmiş örnek** seçili aralığın ilk sekiz saniyesini oluşturur. Örneği kapatınca geçici iş serbest kalır. Dinamik dengeleme sabit LUFS hedefi değildir.
- Proje klibini seçip **Ayarlar → Sonraki klibe geçiş** altında kararıp açılma, çapraz çözünme veya sola kaydırmayı seç. Süre 0,15–1,5 saniyedir. Kısa kliplerde en fazla komşu kliplerin yarısı kadar örtüşme uygulanır. **Geçişi önizle** gerçek video ve ses geçişini kısa bir FFmpeg örneğiyle oynatır. Normal zaman çizelgesi oynatımı klipler arasında doğrudan geçer.
- **Tek Tıkla Shorts → Ayarlar** altında konuşma zoom'u, ses iyileştirme ve giriş/çıkış fade'i isteğe bağlıdır. Her Short ayrı dosyadır. Ayrı Shorts dosyaları arasında geçiş uygulanmaz. Ortalanmış veya elle ayarlı dikey kadraj, altyazı ve sessizlik temizleme aynı akışta kullanılabilir.

## Tek Tıkla Shorts

1. Sol panelde **AI Araçları → Tek Tıkla Shorts** bölümünden **Shorts için video seç** düğmesini kullan. MP4 veya WebM dosyası seçip **Analiz et**. Türkçe, İngilizce ve otomatik dil seçenekleri vardır.
2. **AI Klip Analizi** içinde 15, 30 veya 60 saniye hedefini seç. Öneriler, Whisper satırlarını cümlelere birleştirir ve yerel E5 vektörleriyle yakın anlamı, olası konu değişimlerini ve tekrarları değerlendirir. Ardışık olası soru ve yanıtlar birlikte tutulmaya çalışılır. İlk üç aday açılır. **Diğer adayları göster** ile toplam beş adaya kadar inceleyebilirsin. Uygun sınır bulunamazsa daha az aday çıkabilir.
3. Başlangıç ve bitişi, sessizlikleri, altyazı metni ve zamanlarını, kadrajı veya kelime vurgusunu gerektiğinde ayarla. Dikey kadraj ortalanır veya mevcut kadraj ayarını kullanır. Kişi takibi bulunmaz. Kelime zaman bilgisi olmayan altyazılar cümle olarak gösterilir. Elle değiştirilen satırların otomatik kelime vurgusu kaldırılır.
4. **Seçili Shorts’ları dışa aktar** veya **Bu klibi kaydet** ve bir yerel klasör seç. Klipler ayrı dosyalar olarak sırayla kaydedilir. Klasör, yeni dosyaların güvenle yayımlanabilmesi için NTFS gibi sabit bağlantı destekli bir dosya sisteminde olmalıdır. İptal edilmeden tamamlanan dosyalar klasörde kalır.

### Yerel semantik model

Whisper konuşmayı yazıya döker. `multilingual-e5-small` satırlardan anlam vektörleri üretir. Model MIT lisanslıdır. Windows uygulaması CPU ile paketlenen ONNX Runtime'ı kullanır. Model dosyaları `%LOCALAPPDATA%\ViralCutAI\semantic-e5-small` içinden okunur. Paketler modele veya kullanıcı verisine ağ üzerinden erişmez. Eksik, bozuk ya da uyumsuz model dosyasında panel kural tabanlı yönteme geçildiğini gösterir. Bu modda anlam bütünlüğü puanı boş kalır.

Başka bir bilgisayarda `scripts\setup-semantic.ps1` onay isteyerek yaklaşık 135 MB indirir ve SHA-256 özetlerini doğrular. Model dosyaları Windows paketlerine veya kaynak ZIP'e yerleştirilmez. [Orijinal MIT model kartı](https://huggingface.co/intfloat/multilingual-e5-small) · [Sabit ONNX sürümü](https://huggingface.co/Xenova/multilingual-e5-small/tree/761b726dd34fb83930e26aab4e9ac3899aa1fa78)

Klip seçim uygunluk skoru, kaynak aralığının anlam bütünlüğü, başlangıç, bitiş, sessizlik, altyazı okunabilirliği ve hedef süre değerlendirmelerini birleştirir. Önceki adaylara benzerlik tekrar elemesinde kullanılır ve ayrı gösterilir. Soru ve yanıt işaretleri tahmindir. Zaman aralığı elle değiştirilirse eski skor kaldırılır.

720p ve 1080p çıktılar 9:16, H.264/AAC ve 30 FPS hedefi kullanır. NVIDIA NVENC başarısız olursa CPU devreye girer. Klip zamanları ve ayarları tek tık oturumuna aittir. Mevcut çoklu klip proje kayıtları ayrı olarak çalışır.

## Masaüstü çalışma alanı

- Sol panelde **Medya**, **Altyazı**, **Ses**, **AI Araçları** ve **Efektler** sekmeleri bulunur. Efektler sekmesinde manuel kadraj ve en-boy oranı ayarları yer alır. Sağ panel kaynak ve proje ayarlarıyla dışa aktarmayı gösterir. Bölücüler fareyle sürüklenebilir veya odaklandığında ok tuşlarıyla ayarlanabilir.
- Proje çizelgesinde **Video**, **Ses** ve **Altyazı** hizalı şeritlerdir. Klipler sıralı ve boşluksuzdur. Kaynak ses ve altyazılar kliple birlikte hareket eder. Bağımsız ses klibi bindirme veya video katmanlama yoktur. Sağ panelden klibin sesini kapatabilirsin.
- **Medya → Hafif önizleme oluştur** isteğe bağlı, en çok 640 × 480 boyutunda bir oynatma kopyası üretir. Dışa aktarmada her zaman bağlı orijinal kullanılır. **Ses → Dalga biçimini çıkar** geçerli kaynağın ses seviyesini şeritte gösterir. Hazırlık işleri sıraya alınır ve iptal edilebilir. Önizleme kopyaları oturum sonunda temizlenir.
- **Altyazı → Konuşma metninden düzenle** bölümünde bir satıra tıklamak kaynak videoda o aralığı seçer ve başlangıcına gider. Birden fazla satırı işaretleyip kaynak kliplerden çıkarabilir veya sıraya ekleyebilirsin.
- **Ctrl+Z**, **Ctrl+Y** veya **Ctrl+Shift+Z** geçmişi yönetir. Video şeridinde seçili klipte **Delete** siler, **S** oynatma konumunda böler. **Boşluk** oynatır veya duraklatır.

## Çoklu klip projeleri

1. Windows uygulamasındaki **Projeye video ekle** düğmesinden MP4 ve WebM kaynaklarını seç. Sırayı değiştirmek için klibi sürükle veya taşıma düğmelerini kullan.
2. Klip seçip proje zaman çizelgesindeki başlangıç/bitiş alanlarını düzenle. Oynatma konumundan bölebilir, silebilir ve aynı kaynaktaki bitişik parçaları tekrar birleştirebilirsin. Farklı kaynaklardan klipler dışa aktarılırken sırayla birleştirilir.
3. Aktif klip için **Otomatik altyazı** oluştur. Metni ve konuşma satırının başlangıç/bitişini burada düzelt. **Konuşma metninden düzenle** bölümünden satırları sıraya ekleyebilir veya ilgili kaynak aralıklarını kliplerden çıkarabilirsin. Metni ya da zamanı değiştirilen satırın otomatik kelime vurgusu sıfırlanır.
4. **Projeyi kaydet** bir `.viralcut` dosyası yazar. Proje video kopyalarını içermez. Kaynaklar taşınırsa **Yeni konumu seç** ile aynı dosyayı tekrar bağla. Otomatik kurtarma son yerel taslağı saklar. Uygulamayı yeniden açınca **Otomatik kaydı kurtar** düğmesi görünür.
5. Proje için 720p veya 1080p, FPS ve kalite seç. Bitrate sıfırsa kalite ayarı, pozitifse hedef bitrate uygulanır. **Bu kadrajı projede kullan** etkin kadrajı tüm proje çıktısına uygular. **Projeyi dışa aktar** tamamlandığında süre ve akışlar doğrulanır. Seçili altyazılar çıktıya işlenir.

Projede 100 kaynak ve 500 klip sınırı vardır. Önizleme geçişlerinde sonraki kaynak yüklenirken kısa bir bekleme olabilir. Nihai MP4 tek bir zaman çizelgesine birleştirilir. Geri alma geçmişi oturumluk, medya bağlantıları, altyazı, klipler ve çıktı profili kalıcıdır. Özel altyazı dosyaları (SRT/VTT) etkin kaynağın zaman çizelgesini kullanır.

Masaüstü uygulaması kendi Electron penceresini, FFmpeg/FFprobe ve Whisper CPU motorunu içerir. Model olarak mevcut `%LOCALAPPDATA%\ViralCutAI\ggml-base-q5_1.bin` dosyasını arar. Gerektiğinde **Model dosyasını seç** düğmesini kullan. Model SHA-256 ile doğrulanır. Yerel CUDA motoru varsa otomatik işlemci seçimi onu kullanabilir. MP4 dosya konumu Windows kayıt penceresinden seçilir.

Whisper CPU motoru, Windows'ta Microsoft Visual C++ v14 x64 çalışma zamanını kullanır. Bu bileşen yoksa uygulama bilgi verir. [Microsoft Visual C++ çalışma zamanı](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist)

Üretim için `npm run package:win` çalıştırılır. Paketleme sırasında `desktop-resources` altında FFmpeg, Whisper ve lisans dosyalarının hazır olması gerekir. Ayrıntılar `desktop/THIRD-PARTY.md` dosyasındadır.

## Tarayıcıda geliştirme ve tek klip kullanımı

1. Bu klasördeki **ViralCut AI Ac.cmd** dosyasına çift tıkla. Editör varsayılan tarayıcıda açılır. Adresi `http://127.0.0.1:4173/`.
2. **Video aç** düğmesine tıkla veya MP4/WebM dosyanı önizleme alanına sürükle.
3. Zaman cetveline tıklayarak videoda ilerle. Seçim tutamaçlarını sürükleyebilir, başlangıç ve bitişi saniye olarak yazabilir ya da makas düğmeleriyle oynatma konumundan işaretleyebilirsin.
4. **MP4 dışa aktarma** bölümüne bir dosya adı yaz ve **Klibi hazırla** düğmesine tıkla. Yüzde göstergesinden ilerlemeyi takip edebilir veya **İptal et** ile işlemi durdurabilirsin.
5. Klip hazır olduğunda **MP4 olarak kaydet** düğmesine tıkla. Edge ve Chrome kayıt penceresini desteklediğinde klasörü ve adı orada seçebilirsin. Diğer tarayıcılar indirme yöntemini kullanır. Bu yöntemde klasörü her seferinde seçmek için tarayıcının indirme ayarından kayıt konumunun sorulmasını aç.
6. Uygulamadan çıkarken başlatıcının komut penceresini kapat.

## Shorts ve sessizlik temizleme

1. Videoyu açınca otomatik ses taraması başlar. **Sessizlik Temizle** alanında eşiği ve asgari süreyi ayarlayıp yeniden tarayabilirsin. Zaman çizelgesindeki turuncu işaretler seçilen kesimleri gösterir.
2. Kaldırılacak bölgeleri işaretle ve konuşma sınırlarında bırakılacak süreyi **Koruma** alanından ayarla. **Önce** kaynak oynatmayı, **Düzenlenmiş önizleme** seçilen boşlukları atlayan oynatmayı gösterir.
3. **Kadraj Ayarları** alanından kaynak oranı, 9:16, 1:1 veya 16:9 seç. Yakınlaştırma ve konum kontrolleri kırpılacak alanı belirler. Önizleme kaynak zamanı kullanır. Çıktıda kesilen bölümler kaldırılır ve altyazılar yeniden zamanlanır.
4. **Akıllı Klipler** için önce Whisper altyazısı oluştur. 15, 30 veya 60 saniye hedefinden birini seç. Öneriler cümle sonları ve duraklamalardan hesaplanır. Uygun sınır yoksa öneri gelmeyebilir. Seçilen klibin aralığını zaman çizelgesinden değiştirip her klibi ayrı MP4 olarak kaydedebilirsin.

Shorts ve sessizlikli kesim işlerinde **Otomatik** kodlayıcı NVENC'i dener ve gerektiğinde CPU'ya döner. Dönüştürülen çözünürlük kaynak ayrıntısını geri getirmez. Çok sayıda kesim için geçici diskte yer gerekir. Otomatik yüz/kişi takibi bu sürümde bulunmuyor.

## Otomatik altyazı

1. Videoyu açıp **Otomatik altyazı** bölümüne git. Konuşma dili için otomatik algılama, Türkçe veya İngilizce seç.
2. **Altyazı oluştur** düğmesine tıkla. İşlem süresince videoyu önizleyebilir veya işlemi iptal edebilirsin.
3. Altyazının başlangıç ve bitiş saniyesini veya metnini düzenle. Zaman çizelgesindeki CC şeridi, tıkladığın altyazının başına götürür. **Altyazı görünümü** bölümünde stil, yazı tipi, boyut, konum ve renkleri değiştir.
4. **SRT** ve **VTT** düğmeleri tüm altyazıları kaynak videonun zamanlarıyla kaydeder. Kesilmiş MP4 için **Altyazıları videoya işle** seçeneğini açık bırak. Altyazılar seçilen aralığa göre kırpılır ve yeni zaman çizelgesine kaydırılır.

Kelime vurgusu Whisper'ın tahmini zamanlarına dayanır. Kullanılabilir kelime zamanları bulunmayan satırlar düz metin olarak gösterilir. Satır metnini veya zamanını değiştirince o satırın kelime vurgusu düşer. Altyazı çalışması sekmede tutulur. Videoyu değiştirmeden veya sekmeyi kapatmadan önce SRT/VTT ya da MP4 olarak kaydet.

### Yeni bir bilgisayarda Whisper kurulumu

Mevcut bilgisayarda model, onayla yerel olarak kuruldu. Başka bir Windows bilgisayarında proje klasöründen PowerShell ile CPU motorunu ve modeli kurabilirsin.

```powershell
.\scripts\setup-whisper.ps1 -Cpu
.\scripts\setup-whisper.ps1 -Model
```

Model komutu indirmeden önce onay ister. Çok dilli Base Q5 modeli yaklaşık 57 MiB yer kaplar. Dosyalar `%LOCALAPPDATA%\ViralCutAI` altına kaydedilir. Başlatıcı ve uygulama kendiliğinden model indirmez. İlk kurulumdan sonra internet gerekmez.

NVIDIA hızlandırması için CUDA motoru ve cuBLAS kütüphanesi ayrı komutlarla kurulur. Bu iki indirme yaklaşık 285 MB ve 427 MB boyutundadır. **Otomatik (GPU / CPU)** seçimi CUDA'yı dener ve gerekirse CPU'ya döner. Sonuçta fiilen kullanılan işlemci gösterilir. **CPU** seçeneği GPU kullanımını kapatır.

```powershell
.\scripts\setup-whisper.ps1
.\scripts\setup-whisper.ps1 -CudaLibraries
```

Başlatıcı Node.js ve bağımlılık durumunu kontrol eder, kilit dosyasından eksikleri kurar ve güncel kaynak kodu derler. Tarayıcı, yerel servis FFmpeg, FFprobe, Whisper motoru ve model doğrulamasını bitirdikten sonra açılır. Adresi elle açmak için `http://127.0.0.1:4173/` veya `http://localhost:4173/` kullanabilirsin.

4173 portunda aynı proje klasörünün doğrulanmış servisi çalışıyorsa başlatıcı onu kullanır. Diğer süreçlere dokunmaz. Port çakışmasında eski bir ViralCut komut penceresi açıksa o pencereyi kapatıp başlatıcıyı tekrar çalıştır. Başka bir bilgisayarda Node.js 22.12 veya üzeri ve ilk kurulum için internet gerekir. PATH üzerinde libx264, AAC ve libass destekli FFmpeg ile FFprobe bulunmalıdır. Başlatıcı, Windows'ta Gyan FFmpeg'in WinGet kurulum klasörünü de kontrol eder. Kurulumdan sonra video işleme çevrimdışı çalışır.

MP4 ve WebM oynatma, tarayıcının dosyada kullanılan kodeki desteklemesine bağlıdır. Üç altyazı stili örnek metinle önizlenir. Dışa aktarma seçili aralığı H.264 ve AAC ile yeniden kodlar. Kesim zamanları kaynak videonun kare ve ses örneği zamanlarına tabidir. Çift piksel boyutları korunur. Tek sayılı boyut gerekirse uyumluluk için bir piksel doldurulur. Geçici diskte kaynak kopyası ve çıktı için boş alan gerekir.

## Geliştirme ve test

- `npm ci` kilitli bağımlılıkları kurar.
- `npm run dev` geliştirme sunucusunu çalıştırır.
- `npm run typecheck` TypeScript denetimini yapar.
- `npm run build` üretim derlemesini hazırlar.
- `npm test` editör akışını, dışa aktarmayı ve altyazı düzenlemeyi test eder. Chrome'u mevcut editör akışı testine dahil etmek için `$env:VIRALCUT_TEST_BROWSERS = 'msedge,chrome'` kullan.
- Gerçek Whisper testini de çalıştırmak için önce modeli onayla kur, sonra `$env:VIRALCUT_SPEECH_TEST = '1'` ayarla ve `npm test` çalıştır. Bu test PowerShell 7 ile yerel Windows Microsoft Tolga ve Zira seslerini kullanır. Lisanslı veya kişisel test medyası gerekmez.

## Yerel işleme mimarisi

- `src/editor/model.ts` video bilgilerini, saniye tabanlı klip aralığını ve altyazı stili kimliklerini tarayıcıdan bağımsız tiplerle temsil eder.
- `src/editor/useVideo.ts` dosyanın Blob URL'sini, oynatıcının yaşam döngüsünü ve aralık doğrulamasını yönetir. Dosyanın tamamını JavaScript belleğine kopyalamaz. Oynatma ve çözme işini tarayıcıya bırakır. Video değiştirildiğinde eski URL serbest bırakılır.
- `src/editor/Timeline.tsx` zaman çizelgesini ve aralık kontrollerini sunar. React arayüzü bir Windows kabuğuna taşınabilir.
- `src/export/client.ts` tarayıcı ile yerel servis arasındaki aktarımı yönetir. Tarayıcı kayıt konumunu belirler ve çıktı dosyaya akıtılır.
- `server/export.mjs` yalnızca 127.0.0.1 üzerinden çalışan, aynı kaynakla sınırlı bir API sunar. Tarayıcıdan gelen dosyayı geçici diske akıtır ve bir seferde tek iş yürütür. Başarılı yazım, iptal ve zaman aşımında geçici dosyalar temizlenir. Zorla kapatma sonrasında eski çalışma dizinleri bir sonraki açılışta kontrol edilir.
- `server/media.mjs` FFmpeg ve FFprobe'u komut kabuğu olmadan, hizmetin belirlediği yollar ve komut seçenekleriyle ayrı işlemlerde çalıştırır. Electron'a geçildiğinde aynı kodlama modülü ana süreçten çağrılabilir ve tarayıcı API'sinin yerini dar kapsamlı bir IPC köprüsü alabilir.
- `server/whisper.mjs` FFmpeg ile en çok beş dakikalık 16 kHz mono WAV parçaları üretir. Whisper ayrı ve iptal edilebilir bir süreçte çalışır. Dil algılama parça başına yapılır. Kelime ve satır zamanları kaynak videonun zamanına taşınır. Bir altyazı, parça sınırına denk gelirse cümle bölünebilir.
- `server/ass.mjs` kaydetme için sınırlı stil seçeneklerini doğrular ve FFmpeg/libass için ASS altyazı üretir. Altyazı biçiminin MP4'e işlenmesi libass destekli FFmpeg gerektirir.

