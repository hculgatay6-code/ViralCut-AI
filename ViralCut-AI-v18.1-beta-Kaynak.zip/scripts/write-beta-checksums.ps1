param([string]$Release = (Join-Path (Split-Path -Parent $PSScriptRoot) 'release'))

$ErrorActionPreference = 'Stop'
$folder = (Resolve-Path -LiteralPath $Release).Path
$names = @('ViralCut-AI-v18.1-beta-Setup.exe', 'ViralCut-AI-v18.1-beta-Portable.exe')
$lines = foreach ($name in $names) {
  $hash = (Get-FileHash -LiteralPath (Join-Path $folder $name) -Algorithm SHA256).Hash
  $hash.ToLowerInvariant() + '  ' + $name
}
$lines | Set-Content -LiteralPath (Join-Path $folder 'SHA256SUMS-v18.1-beta.txt') -Encoding ascii
